<?php

/**
 * @generate-class-entries
 * @undocumentable
 */

function dl_test_test1(): void {}

function dl_test_test2(string $str = ""): string {}
